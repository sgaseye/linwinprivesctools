from . import run_check

if __name__ == '__main__':
    run_check()