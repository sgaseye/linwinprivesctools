namespace SharpCifs.Util.Sharpen
{
    internal abstract class Reference<T>
	{
	    public abstract T Get ();
	}
}
