namespace SharpCifs.Util.Sharpen
{
	internal interface ICallable<T>
	{
		T Call ();
	}
}
