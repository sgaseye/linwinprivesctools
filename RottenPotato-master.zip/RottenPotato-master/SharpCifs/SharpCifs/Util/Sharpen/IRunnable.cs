namespace SharpCifs.Util.Sharpen
{
    public interface IRunnable
	{
		void Run ();
	}
}
