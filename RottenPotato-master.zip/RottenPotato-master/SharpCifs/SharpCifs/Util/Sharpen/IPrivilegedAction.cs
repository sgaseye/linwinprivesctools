namespace SharpCifs.Util.Sharpen
{
	internal interface IPrivilegedAction<T>
	{
		T Run ();
	}
}
