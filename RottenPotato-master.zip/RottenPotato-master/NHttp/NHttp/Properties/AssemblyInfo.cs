﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("NHttp")]
[assembly: AssemblyDescription("Simple asynchronous .NET HTTP server")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Pieter van Ginkel")]
[assembly: AssemblyProduct("NHttp")]
[assembly: AssemblyCopyright("Pieter van Ginkel © 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]

[assembly: Guid("86f3c50f-4103-4f12-9992-41d2cc4549f1")]

[assembly: AssemblyVersion("0.1.8.0")]
[assembly: AssemblyFileVersion("0.1.8.0")]
